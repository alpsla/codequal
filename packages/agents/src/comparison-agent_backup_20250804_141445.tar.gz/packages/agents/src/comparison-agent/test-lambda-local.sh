#!/bin/bash

# Test Lambda function locally using serverless framework
# This script tests the actual Lambda handler

echo "🧪 Testing Comparison Agent Lambda Function Locally"
echo "================================================="

# Check if serverless is installed
if ! command -v serverless &> /dev/null; then
    echo "❌ Serverless framework not installed. Installing..."
    npm install -g serverless
fi

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
fi

# Create test event file
cat > test-event.json << 'EOF'
{
  "body": "{\"mainBranchReport\":{\"overall_score\":70,\"issues\":[{\"id\":\"SEC-001\",\"title\":\"SQL Injection\",\"severity\":\"critical\",\"category\":\"security\",\"file_path\":\"src/db.ts\",\"line_number\":45,\"description\":\"SQL injection vulnerability\",\"code_snippet\":\"query(`SELECT * FROM users WHERE id = ${id}`)\",\"recommendation\":\"Use parameterized queries\"},{\"id\":\"PERF-001\",\"title\":\"N+1 Query\",\"severity\":\"high\",\"category\":\"performance\",\"file_path\":\"src/api.ts\",\"line_number\":100,\"description\":\"Multiple queries in loop\",\"recommendation\":\"Batch queries\"}],\"metadata\":{\"repository\":\"test/repo\",\"branch\":\"main\",\"commit\":\"abc123\",\"analysis_date\":\"2025-01-30\",\"model_used\":\"gpt-4o-mini\"}},\"featureBranchReport\":{\"overall_score\":78,\"issues\":[{\"id\":\"PERF-001\",\"title\":\"N+1 Query\",\"severity\":\"high\",\"category\":\"performance\",\"file_path\":\"src/api.ts\",\"line_number\":100,\"description\":\"Multiple queries in loop\",\"recommendation\":\"Batch queries\"}],\"metadata\":{\"repository\":\"test/repo\",\"branch\":\"feature/fix-security\",\"commit\":\"def456\",\"analysis_date\":\"2025-01-30\",\"model_used\":\"gpt-4o-mini\"}},\"prMetadata\":{\"pr_number\":123,\"pr_title\":\"Fix security issues\",\"files_changed\":[\"src/db.ts\"],\"lines_added\":50,\"lines_removed\":25,\"author_id\":\"user-123\",\"author_skills\":{\"security\":60,\"performance\":70,\"quality\":65}}}",
  "headers": {
    "Content-Type": "application/json"
  },
  "httpMethod": "POST",
  "path": "/compare"
}
EOF

echo ""
echo "📋 Test Event Created"
echo "  - Main branch: 2 issues (1 critical security, 1 high performance)"
echo "  - Feature branch: 1 issue (performance remains)"
echo "  - Expected: Security fixed, performance unchanged"
echo ""

# Run the Lambda function locally
echo "🚀 Invoking Lambda function locally..."
echo "======================================"
serverless invoke local -f compareReports -p test-event.json

# Clean up
rm -f test-event.json

echo ""
echo "✅ Test completed!"
echo ""
echo "📝 Next steps:"
echo "  1. Deploy to AWS: npm run deploy:dev"
echo "  2. Test deployed function: serverless invoke -f compareReports -p test-event.json"
echo "  3. Check logs: npm run logs"
echo "  4. Monitor dashboard: Check CloudWatch in AWS Console"